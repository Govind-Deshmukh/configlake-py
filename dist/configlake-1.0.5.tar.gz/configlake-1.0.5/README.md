# Config Lake - Python Client

Simple Python client library for Config Lake - fetch and decrypt configurations and secrets from your centralized config management server.

## Features

- 🔐 **Secure**: End-to-end encryption for secrets
- 🚀 **Simple**: Easy-to-use API with minimal setup  
- ⚡ **Fast**: Lightweight with minimal dependencies
- 🛡️ **Safe**: Input validation and error handling

## Installation

```bash
pip install configlake
```

## Quick Start

```python
import configlake

# Configuration
API_URL = "http://localhost:5000"
API_TOKEN = "your-api-token"
PROJECT_ID = 1
ENVIRONMENT = "production"

# Get plain-text configurations
configs = configlake.get_config(API_URL, API_TOKEN, PROJECT_ID, ENVIRONMENT)
print("Database URL:", configs.get("DATABASE_URL"))

# Get decrypted secrets
secrets = configlake.get_secrets(API_URL, API_TOKEN, PROJECT_ID, ENVIRONMENT)
print("API Key:", secrets.get("SECRET_API_KEY"))

# Get both configs and secrets together
all_data = configlake.get_all_details(API_URL, API_TOKEN, PROJECT_ID, ENVIRONMENT)
print("Configs:", all_data["configs"])
print("Secrets:", all_data["secrets"])
```

## API Reference

### `get_config(base_url, token, project_id, environment)`

Fetches plain-text configuration values for a specific project and environment.

**Parameters:**
- `base_url` (str): Base URL of your Config Lake server
- `token` (str): Your API authentication token
- `project_id` (int): ID of the project
- `environment` (str): Name of the environment (e.g., "dev", "staging", "production")

**Returns:** Dictionary of configuration key-value pairs

### `get_secrets(base_url, token, project_id, environment)`

Fetches and decrypts secret values for a specific project and environment.

**Parameters:**
- `base_url` (str): Base URL of your Config Lake server
- `token` (str): Your API authentication token
- `project_id` (int): ID of the project
- `environment` (str): Name of the environment

**Returns:** Dictionary of decrypted secret key-value pairs

### `get_all_details(base_url, token, project_id, environment)`

Fetches both configurations and secrets in a single request.

**Parameters:**
- `base_url` (str): Base URL of your Config Lake server
- `token` (str): Your API authentication token
- `project_id` (int): ID of the project
- `environment` (str): Name of the environment

**Returns:** Dictionary containing:
- `configs`: Dictionary of configuration values
- `secrets`: Dictionary of decrypted secret values
- `project_id`: The project ID
- `environment`: The environment name

## Backwards Compatibility

The library also supports the original function names:

```python
# These work the same as the new function names
configs = configlake.getConfig(API_URL, API_TOKEN, PROJECT_ID, ENVIRONMENT)
secrets = configlake.getSecrets(API_URL, API_TOKEN, PROJECT_ID, ENVIRONMENT)
all_data = configlake.getAllDetails(API_URL, API_TOKEN, PROJECT_ID, ENVIRONMENT)
```

## Error Handling

The library raises `ConfigLakeError` for various error conditions:

```python
try:
    configs = configlake.get_config(API_URL, API_TOKEN, PROJECT_ID, ENVIRONMENT)
except configlake.ConfigLakeError as e:
    print(f"Error fetching config: {e}")
```

## Environment Variables

You can store your configuration in environment variables:

```python
import os
import configlake

API_URL = os.getenv("CONFIGLAKE_URL", "http://localhost:5000")
API_TOKEN = os.getenv("CONFIGLAKE_TOKEN")
PROJECT_ID = int(os.getenv("CONFIGLAKE_PROJECT_ID", "1"))
ENVIRONMENT = os.getenv("CONFIGLAKE_ENVIRONMENT", "development")

configs = configlake.get_config(API_URL, API_TOKEN, PROJECT_ID, ENVIRONMENT)
```

## Requirements

- Python 3.7+
- requests
- cryptography

## License

MIT License - see LICENSE file for details.